<?php
if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}
?>{{ featured_image:<?php echo http_build_query( $atts ) ?> }}
